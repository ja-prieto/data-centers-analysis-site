"""Piezas compartidas: numeros en espanol, tarjetas y barras de ranking.

El formato es el problema de fondo. d3 solo sabe formatear a la inglesa
(«1,234.5») y el espanol usa los dos simbolos al reves, asi que `es_format`
los intercambia **a traves de un marcador**: una secuencia de reemplazos
directos convertiria los dos separadores en el mismo.

En el proyecto del que viene este modulo los tooltips no pasaban por ahi y
salian con separadores ingleses mientras los ejes salian bien. Aqui pasan los
dos: `tooltip_es` genera el campo calculado que hace falta.
"""

from __future__ import annotations

from collections.abc import Iterable
from math import isnan

import altair as alt

from tema import BORDE, NEUTRO, REJILLA, ROJO, SUAVE, TEXTO, TINTA, VERDE

MILLON = 1_000_000
MIL_MILLONES = 1_000_000_000


def es_format(valor: str, spec: str = ",.0f", sufijo: str = "") -> str:
    """Expresion de Vega que formatea `valor` con separadores espanoles."""
    texto = f"format({valor}, '{spec}')"
    cambiado = f"replace(replace(replace({texto}, /\\./g, '@'), /,/g, '.'), /@/g, ',')"
    return f"{cambiado} + '{sufijo}'" if sufijo else cambiado


def es_numero(valor: float, decimales: int = 0) -> str:
    return f"{valor:,.{decimales}f}".translate(str.maketrans({",": ".", ".": ","}))


def es_euros(valor: float) -> str:
    """Euros a una escala legible: EUR, M EUR o mm EUR segun el tamano."""
    if abs(valor) >= MIL_MILLONES:
        return f"{es_numero(valor / MIL_MILLONES, 1)} mm EUR"
    if abs(valor) >= MILLON:
        return f"{es_numero(valor / MILLON, 1)} M EUR"
    return f"{es_numero(valor)} EUR"


def eje_dinero(titulo: str | None, spec: str = ",.0f", sufijo: str = " M EUR", **kwargs):
    return alt.Axis(title=titulo, labelExpr=es_format("datum.value", spec, sufijo), **kwargs)


def tooltip_es(campo: str, titulo: str) -> alt.Tooltip:
    """Tooltip numerico con separadores espanoles.

    Vega-Lite no admite `labelExpr` en un tooltip, asi que el formato se calcula
    como campo derivado y el valor viaja ya convertido en texto. El hueco sale
    como «sin dato», no como cero: es el convenio numero uno de la base.

    **Apunta a `<campo>_txt`, que tiene que haber creado `con_texto_es`.** El
    formato se declara alli y solo alli: si esta funcion aceptara tambien un
    `spec`, habria dos sitios donde decir el mismo formato y acabarian
    discrepando.
    """
    return alt.Tooltip(f"{campo}_txt:N", title=titulo)


def con_texto_es(
    grafico: alt.Chart, campos: dict[str, tuple[str, str]]
) -> alt.Chart:
    """Anade un `<campo>_txt` formateado a la espanola por cada campo numerico.

    `campos` es `{campo: (spec, sufijo)}`.
    """
    for campo, (spec, sufijo) in campos.items():
        grafico = grafico.transform_calculate(
            **{
                f"{campo}_txt": (
                    f"isValid(datum['{campo}']) ? "
                    f"{es_format(f"datum['{campo}']", spec, sufijo)} : 'sin dato'"
                )
            }
        )
    return grafico


# --------------------------------------------------------------------------- #
# Componentes HTML
# --------------------------------------------------------------------------- #


def tarjetas(items: Iterable[tuple[str, str, str]]) -> str:
    """Fila de cifras de cabecera, cada una `(etiqueta, valor, nota)`."""
    tarjetas_html = "".join(
        f"""<div style="flex:1 1 170px;padding:14px 16px;border:1px solid {REJILLA};
             border-left:3px solid {ROJO};border-radius:2px;background:#FFFFFF">
          <div style="font-size:11px;letter-spacing:.06em;text-transform:uppercase;
               color:{SUAVE}">{etiqueta}</div>
          <div style="font-size:24px;font-weight:600;color:{TINTA};margin-top:4px">{valor}</div>
          <div style="font-size:11px;color:{TEXTO};margin-top:2px">{nota}</div>
        </div>"""
        for etiqueta, valor, nota in items
    )
    return (
        f'<div style="display:flex;flex-wrap:wrap;gap:12px;margin:8px 0 4px">'
        f"{tarjetas_html}</div>"
    )


def aviso(texto: str) -> str:
    """Pie discreto para las advertencias que en estos datos no dejan de salir."""
    return (
        f'<div style="font-size:12px;color:{TEXTO};border-left:2px solid {BORDE};'
        f'padding:2px 0 2px 10px;margin:6px 0">{texto}</div>'
    )


def pasos(titulo: str, subtitulo: str, items: Iterable[tuple[str, str]]) -> str:
    """Cadena numerada de pasos, cada uno `(que, por que)`.

    Es lo primero que ve alguien que no conoce el proyecto, y lo unico que
    tiene que contestar es **de donde sale un dato**. Va en HTML y no en un
    grafico porque no hay ninguna magnitud que dibujar: es una secuencia, y
    dibujar una secuencia como barras seria fingir que se mide algo.
    """
    tarjetas_html = "".join(
        f"""<div style="flex:1 1 160px;min-width:150px;padding:12px 14px;
             border:1px solid {REJILLA};border-radius:2px;background:#FFFFFF">
          <div style="display:inline-flex;align-items:center;justify-content:center;
               width:20px;height:20px;border-radius:10px;background:{ROJO};
               color:#FFFFFF;font-size:11px;font-weight:600">{n}</div>
          <div style="font-size:13px;font-weight:600;color:{TINTA};margin-top:7px">{que}</div>
          <div style="font-size:11.5px;color:{TEXTO};margin-top:3px;
               line-height:1.45">{porque}</div>
        </div>"""
        for n, (que, porque) in enumerate(items, start=1)
    )
    return (
        f'<div style="border:1px solid {BORDE};border-left:3px solid {ROJO};'
        f'border-radius:2px;padding:12px 14px;background:#FFFFFF;margin:8px 0">'
        f'<div style="font-size:13px;font-weight:600;color:{TINTA}">{titulo}</div>'
        f'<div style="font-size:11.5px;color:{SUAVE};margin-bottom:10px">{subtitulo}</div>'
        f'<div style="display:flex;flex-wrap:wrap;gap:10px">{tarjetas_html}</div>'
        "</div>"
    )


def definiciones(titulo: str, subtitulo: str, items: Iterable[tuple[str, str]]) -> str:
    """Vocabulario controlado, cada entrada `(termino, que significa)`.

    Las columnas `fiabilidad` y `verificacion` son vocabulario cerrado y sus
    valores no se explican solos: `no_comprobable` **no es un aprobado**, y
    `OFICIAL-NP` es oficial y no es el expediente. Quien lee la tabla sin esto
    tiene que adivinar, y adivina mal.
    """
    filas_html = "".join(
        f"""<div style="display:flex;gap:10px;padding:7px 0;
             border-top:1px solid {BORDE}">
          <div style="flex:0 0 148px;font-size:12px;font-weight:600;color:{TINTA};
               font-family:ui-monospace,SFMono-Regular,Menlo,monospace">{termino}</div>
          <div style="flex:1;font-size:11.5px;color:{TEXTO};line-height:1.5">{texto}</div>
        </div>"""
        for termino, texto in items
    )
    return (
        f'<div style="border:1px solid {BORDE};border-left:3px solid {NEUTRO};'
        f'border-radius:2px;padding:12px 14px;background:#FFFFFF;margin:8px 0">'
        f'<div style="font-size:13px;font-weight:600;color:{TINTA}">{titulo}</div>'
        f'<div style="font-size:11.5px;color:{SUAVE}">{subtitulo}</div>'
        f"{filas_html}</div>"
    )


def tabla(
    titulo: str,
    subtitulo: str,
    cabeceras: Iterable[str],
    filas: Iterable[Iterable[str]],
    anchos: Iterable[str] | None = None,
) -> str:
    """Tabla de prosa corta: fuentes, campos, quien da que.

    No es `mo.ui.table`, que es para recorrer un marco de datos de cientos de
    filas. Esto son cinco o seis filas escritas para leerse enteras, con la
    primera columna en negrita porque es la que se busca con la vista.
    """
    anchos = list(anchos or [])
    cols = "".join(
        f'<col style="width:{a}">' for a in anchos
    )
    cabecera = "".join(
        f'<th style="text-align:left;padding:6px 10px;font-size:10.5px;'
        f'letter-spacing:.06em;text-transform:uppercase;color:{SUAVE};'
        f'font-weight:600">{c}</th>'
        for c in cabeceras
    )
    cuerpo = "".join(
        "<tr>"
        + "".join(
            f'<td style="padding:8px 10px;border-top:1px solid {BORDE};'
            f'font-size:11.5px;line-height:1.5;vertical-align:top;'
            f'color:{TINTA if i == 0 else TEXTO};'
            f'font-weight:{600 if i == 0 else 400}">{celda}</td>'
            for i, celda in enumerate(fila)
        )
        + "</tr>"
        for fila in filas
    )
    return (
        f'<div style="border:1px solid {BORDE};border-left:3px solid {ROJO};'
        f'border-radius:2px;padding:12px 14px;background:#FFFFFF;margin:8px 0">'
        f'<div style="font-size:13px;font-weight:600;color:{TINTA}">{titulo}</div>'
        f'<div style="font-size:11.5px;color:{SUAVE};margin-bottom:4px">{subtitulo}</div>'
        f'<div style="overflow-x:auto">'
        f'<table style="border-collapse:collapse;width:100%;min-width:520px">'
        f"<colgroup>{cols}</colgroup>"
        f"<thead><tr>{cabecera}</tr></thead><tbody>{cuerpo}</tbody></table></div></div>"
    )


def tabla_plegable(
    titulo: str,
    subtitulo: str,
    cabeceras: Iterable[str],
    grupos: Iterable[tuple[str, list[Iterable[str]], bool]],
    anchos: Iterable[str] | None = None,
) -> str:
    """La misma tabla, partida en bloques que se pliegan y despliegan.

    Para la ficha de un proyecto, que tiene treinta filas y casi siempre se
    lee buscando un bloque (la potencia, la inversión). Cada grupo es
    `(nombre, filas, abierto)`; el resumen dice cuántas filas tienen dato, para
    que un bloque plegado no esconda si hay algo dentro. Es `<details>` de HTML:
    no necesita estado ni JavaScript, así que funciona igual en la web compilada.
    """
    anchos = list(anchos or [])
    cols = "".join(f'<col style="width:{a}">' for a in anchos)
    cabecera = "".join(
        f'<th style="text-align:left;padding:6px 10px;font-size:10.5px;'
        f'letter-spacing:.06em;text-transform:uppercase;color:{SUAVE};'
        f'font-weight:600">{c}</th>'
        for c in cabeceras
    )

    def _filas(filas):
        return "".join(
            "<tr>"
            + "".join(
                f'<td style="padding:8px 10px;border-top:1px solid {BORDE};'
                f'font-size:11.5px;line-height:1.5;vertical-align:top;'
                f'color:{TINTA if i == 0 else TEXTO};'
                f'font-weight:{600 if i == 0 else 400}">{celda}</td>'
                for i, celda in enumerate(fila)
            )
            + "</tr>"
            for fila in filas
        )

    def _con_dato(filas):
        return sum(1 for f in filas if "desconocido" not in str(list(f)[1]))

    bloques = "".join(
        f'<details{" open" if abierto else ""} style="margin-top:6px">'
        f'<summary style="cursor:pointer;padding:6px 4px;font-size:12px;font-weight:600;'
        f'color:{TINTA};border-top:1px solid {BORDE}">{nombre}'
        f'<span style="font-weight:400;color:{SUAVE};margin-left:8px">'
        f"{_con_dato(filas)} de {len(filas)} con dato</span></summary>"
        f'<div style="overflow-x:auto">'
        f'<table style="border-collapse:collapse;width:100%;min-width:520px;table-layout:fixed">'
        f"<colgroup>{cols}</colgroup><tbody>{_filas(filas)}</tbody></table></div></details>"
        for nombre, filas, abierto in grupos
        if filas
    )
    return (
        f'<div style="border:1px solid {BORDE};border-left:3px solid {ROJO};'
        f'border-radius:2px;padding:12px 14px;background:#FFFFFF;margin:8px 0">'
        f'<div style="font-size:13px;font-weight:600;color:{TINTA}">{titulo}</div>'
        f'<div style="font-size:11.5px;color:{SUAVE};margin-bottom:4px">{subtitulo}</div>'
        f'<div style="overflow-x:auto">'
        f'<table style="border-collapse:collapse;width:100%;min-width:520px;table-layout:fixed">'
        f"<colgroup>{cols}</colgroup><thead><tr>{cabecera}</tr></thead></table></div>"
        f"{bloques}</div>"
    )


def estados(titulo: str, subtitulo: str, filas: Iterable[tuple[str, str, str, bool]]) -> str:
    """Lista de situaciones, cada una `(que, estado, por que, es_pendiente)`.

    Esto no es un grafico y no debe serlo. Antes era un diagrama de barras cuya
    longitud contaba documentos, y cuando las comunidades que faltaban pasaron
    de catorce a cinco la barra dejo de medir nada: cuatro de las cinco valian
    cero, y un grafico con cuatro barras invisibles no dice «no hay dato», dice
    que algo se ha roto. Lo que hay que enseñar aqui es **por que** cada una
    sigue fuera, y eso son palabras.

    `es_pendiente` distingue lo que queda por hacer de lo que ya es un
    resultado. Una comunidad buscada y vacia no es una tarea: poder decir «en
    Navarra no hay», con la busqueda registrada, vale tanto como nombrar un
    expediente en Aragon, y es lo que separa esto de una lista sacada de la
    prensa.
    """
    def _fila(que: str, estado: str, porque: str, pendiente: bool) -> str:
        color = ROJO if pendiente else VERDE
        marca = "pendiente" if pendiente else "resultado"
        return (
            f'<div style="display:flex;gap:10px;padding:9px 0;'
            f'border-top:1px solid {BORDE}">'
            f'<div style="flex:0 0 5px;background:{color};border-radius:3px"></div>'
            f'<div style="flex:1">'
            f'<div style="display:flex;justify-content:space-between;gap:8px">'
            f'<span style="font-weight:600;color:{TINTA};font-size:13px">{que}</span>'
            f'<span style="font-size:10px;letter-spacing:.05em;text-transform:uppercase;'
            f'color:{color};white-space:nowrap">{marca}</span></div>'
            f'<div style="font-size:12px;color:{TINTA};margin-top:1px">{estado}</div>'
            f'<div style="font-size:11.5px;color:{TEXTO};margin-top:3px;'
            f'line-height:1.45">{porque}</div>'
            "</div></div>"
        )

    cuerpo = "".join(_fila(*f) for f in filas)
    return (
        f'<div style="border:1px solid {BORDE};border-left:3px solid {ROJO};'
        f'border-radius:2px;padding:12px 14px;background:#FFFFFF">'
        f'<div style="font-size:13px;font-weight:600;color:{TINTA}">{titulo}</div>'
        f'<div style="font-size:11.5px;color:{SUAVE};margin-bottom:2px">{subtitulo}</div>'
        f"{cuerpo}</div>"
    )


# --------------------------------------------------------------------------- #
# Clases de color: el mapa y la ficha de provincia comparten la misma escala
# --------------------------------------------------------------------------- #


def _redondear(valor: float) -> float:
    """Dos cifras significativas: los cortes de una leyenda se leen, no se calculan."""
    if valor <= 0:
        return 0.0
    from math import floor, log10

    escala = 10 ** (floor(log10(valor)) - 1)
    return round(valor / escala) * escala


def clases(valores: Iterable[float], paleta: list[str], n: int = 5) -> tuple[list[float], list[str]]:
    """Cortes por cuantiles y su color, para una escala `threshold` de Vega-Lite.

    **Clases y no una escala continua.** Con la continua el color de cada
    provincia lo interpola el navegador y no hay forma de repetirlo fuera del
    grafico; con clases, la ficha de provincia pinta exactamente el mismo
    color que el mapa, y cada proyecto puede llevar el de la clase en la que
    caeria el solo. Devuelve `(umbrales, colores)` con un color mas que
    umbrales, que es lo que pide `alt.Scale(type="threshold")`.
    """
    # Cuantiles sobre los valores **distintos**: contando proyectos, media
    # Espana tiene uno o dos, y sobre las provincias los cortes se apilaban en
    # el mismo numero y dejaban dos clases.
    positivos = sorted({v for v in valores if v is not None and not isnan(v) and v > 0})
    if not positivos:
        return [], [paleta[-1]]
    cortes: list[float] = []
    for i in range(1, n):
        c = _redondear(positivos[min(len(positivos) - 1, int(len(positivos) * i / n))])
        if c > positivos[0] and (not cortes or c > cortes[-1]):
            cortes.append(c)
    # Los colores se reparten por la paleta: la clase mas alta lleva siempre el
    # mas intenso y la mas baja uno claro, haya las clases que haya. El primero
    # de la paleta, casi blanco, no se usa: se confunde con el gris de las
    # provincias sin dato, que significan otra cosa.
    utiles = paleta[1:]
    k = len(cortes) + 1
    if k == 1:
        return cortes, [utiles[-1]]
    colores = [utiles[round(i * (len(utiles) - 1) / (k - 1))] for i in range(k)]
    return cortes, colores


def leyenda_umbral() -> str:
    """`labelExpr` para la leyenda de una escala `threshold`, a la espanola.

    La leyenda pinta cada corte bajo su marca; el primer tramo no tiene corte
    debajo y Vega le pone `null` (o «−Infinity» si se formatea el valor). Ese
    rotulo se deja en blanco.
    """
    return f"isValid(datum.value) && isFinite(datum.value) ? {es_format('datum.value')} : ''"


def color_de(valor: float | None, umbrales: list[float], colores: list[str]) -> str | None:
    """El color que la escala `threshold` da a `valor`; `None` si no hay valor."""
    if valor is None or isnan(valor) or valor <= 0:
        return None
    for umbral, color in zip(umbrales, colores, strict=False):
        if valor < umbral:
            return color
    return colores[-1]


def _tinta_sobre(fondo: str) -> str:
    """Texto blanco sobre los tonos oscuros de la paleta, tinta sobre los claros."""
    r, g, b = (int(fondo[i : i + 2], 16) for i in (1, 3, 5))
    return "#FFFFFF" if 0.299 * r + 0.587 * g + 0.114 * b < 150 else TINTA


def chip(texto: str, color: str | None, *, hueco: bool = False) -> str:
    """Una etiqueta con el color de la leyenda del mapa.

    `hueco` reproduce el anillo de los puntos sin proyecto del censo: borde de
    color y fondo blanco.
    """
    if color is None:
        return f'<span style="font-size:11px;color:{SUAVE}">{texto}</span>'
    if hueco:
        estilo = f"border:1.5px solid {color};color:{TINTA};background:#FFFFFF"
    else:
        estilo = f"border:1.5px solid {color};background:{color};color:{_tinta_sobre(color)}"
    return (
        f'<span style="display:inline-block;padding:1px 7px;border-radius:9px;'
        f'font-size:11px;white-space:nowrap;{estilo}">{texto}</span>'
    )


def cabecera_provincia(nombre: str, color: str | None, cifras: Iterable[tuple[str, str, str]]) -> str:
    """La franja que abre la ficha: el nombre sobre el color de la provincia."""
    fondo = color or REJILLA
    tinta = _tinta_sobre(fondo) if color else TINTA
    celdas = "".join(
        f"""<div style="flex:1 1 150px;padding:10px 14px;background:#FFFFFF;
             border:1px solid {REJILLA};border-radius:2px">
          <div style="font-size:10.5px;letter-spacing:.06em;text-transform:uppercase;color:{SUAVE}">{etiqueta}</div>
          <div style="font-size:20px;font-weight:600;color:{TINTA};margin-top:2px">{valor}</div>
          <div style="font-size:11px;color:{TEXTO}">{nota}</div>
        </div>"""
        for etiqueta, valor, nota in cifras
    )
    return (
        f'<div style="border:1px solid {BORDE};border-radius:2px;margin:8px 0;overflow:hidden">'
        f'<div style="background:{fondo};color:{tinta};padding:10px 14px;font-size:16px;'
        f'font-weight:600">{nombre}</div>'
        f'<div style="display:flex;flex-wrap:wrap;gap:10px;padding:10px;background:#FAFAFA">'
        f"{celdas}</div></div>"
    )
