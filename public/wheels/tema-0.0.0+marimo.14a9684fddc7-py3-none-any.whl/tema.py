"""Estilo de casa para los graficos de Altair.

Portado del que usa el proyecto de subvenciones, para que los dos entregables se
lean como uno solo. La regla de diseno es la suya: **un rojo institucional lleva
el dato y todo lo demas es neutro**; la rejilla es el elemento mas claro de la
pagina, el eje se quita donde la rejilla ya hace su trabajo, y los titulos van
alineados a la izquierda encima del grafico.

Dos avisos heredados que cuestan una tarde si se ignoran:

- **Los pesos de fuente se quedan en 400 y 600.** Un 500 intermedio pide una
  Medium que estas pilas no traen, y el render estatico contesta con una fuente
  de simbolos: los titulos de eje salen como galimatias.
- **Todo el estilo va en el diccionario del tema, no en `configure_*`.** Mezclar
  los dos hace que el ultimo que se aplique gane, y deja de estar claro cual es.

Cuantos colores categoricos se pueden usar
------------------------------------------
Cuatro. No es una opinion, esta medido sobre esta misma paleta (distancia OKLab
x100, simulacion Machado-Oliveira-Fernandes de protanopia y deuteranopia):

- Los cuatro primeros (`ROJO`, `AZUL`, `AMBAR`, `VERDE`) se distinguen entre si
  en **todos** los pares: el peor par da 9,6 con daltonismo y 17,8 con vision
  normal, por encima de los umbrales de 6 y 15.
- A partir del quinto **dejan de distinguirse**: `MALVA` y `PIZARRA` dan 7,6 con
  vision normal, es decir que ni siquiera un lector sin daltonismo los separa.

Asi que `CATEGORICAL` se queda en cuatro entradas. Cuando una variable tiene mas
categorias que eso —`tipo_expediente` tiene seis— no se codifica con color: se
dibuja en una serie unica, o en pequenos multiplos. Es ademas lo que pide la
regla de casa, que reserva el color para lo que de verdad hay que comparar.

`SECUENCIAL` es de un solo tono y baja de claro a oscuro sin volver atras
(diferencia minima de luminosidad 0,13). `DIVERGENTE` son dos tonos con un gris
neutro de verdad en el centro (croma 0,000), que es como debe ser una escala de
signo: azul por debajo, rojo por encima.
"""

from __future__ import annotations

import altair as alt

THEME_NAME = "banco-de-espana"

# --- Serie ------------------------------------------------------------------
ROJO = "#9F2D20"
ROJO_CLARO = "#C86B5C"
AZUL = "#2A4B7C"
AZUL_CLARO = "#6E92C0"
AMBAR = "#C9762B"
VERDE = "#4B7F6E"

# --- Tinta y superficie ------------------------------------------------------
TINTA = "#1F2937"
TEXTO = "#4B5563"
SUAVE = "#6B7280"
REJILLA = "#E5E7EB"
BORDE = "#D1D5DB"
FONDO = "#FFFFFF"
NEUTRO = "#9CA3AF"
"""Lo que se excluye, lo que no se ha buscado, el resto. Nunca una serie."""

CATEGORICAL = [ROJO, AZUL, AMBAR, VERDE]
"""Orden fijo, nunca ciclado. Cuatro es el limite medido; ver el docstring."""

SECUENCIAL = ["#F7EFEC", "#E3BCB2", "#C97A68", "#9F2D20", "#5E1A12"]
DIVERGENTE = [AZUL, AZUL_CLARO, "#F1F1F1", ROJO_CLARO, ROJO]

FUENTE = "'Helvetica Neue', Helvetica, Arial, sans-serif"


@alt.theme.register(THEME_NAME, enable=False)
def _tema() -> alt.theme.ThemeConfig:
    return {
        "config": {
            "background": FONDO,
            "font": FUENTE,
            "view": {"stroke": None, "continuousWidth": 620, "continuousHeight": 320},
            "title": {
                "anchor": "start",
                "color": TINTA,
                "font": FUENTE,
                "fontSize": 17,
                "fontWeight": 600,
                "offset": 14,
                "subtitleColor": SUAVE,
                "subtitleFont": FUENTE,
                "subtitleFontSize": 12,
                "subtitlePadding": 8,
            },
            "axis": {
                "labelColor": TEXTO,
                "labelFont": FUENTE,
                "labelFontSize": 11,
                "labelPadding": 6,
                "titleColor": TEXTO,
                "titleFont": FUENTE,
                "titleFontSize": 12,
                "titlePadding": 12,
                "domainColor": BORDE,
                "tickColor": BORDE,
                "tickSize": 4,
                "grid": False,
            },
            "axisY": {"grid": True, "gridColor": REJILLA, "domain": False, "ticks": False},
            "axisX": {"labelAngle": 0},
            "legend": {
                "labelColor": TEXTO,
                "labelFont": FUENTE,
                "labelFontSize": 11,
                "titleColor": TEXTO,
                "titleFont": FUENTE,
                "titleFontSize": 11,
                "symbolType": "square",
                "orient": "top",
                "direction": "horizontal",
                "offset": 8,
            },
            "range": {
                "category": CATEGORICAL,
                "heatmap": SECUENCIAL,
                "ramp": SECUENCIAL,
                "diverging": DIVERGENTE,
            },
            "mark": {"color": ROJO},
            "bar": {"color": ROJO},
            "line": {"color": ROJO, "strokeWidth": 2},
            "point": {"color": ROJO, "filled": True, "size": 45},
            "area": {"color": ROJO, "opacity": 0.85},
            "rule": {"color": BORDE},
            "text": {"color": TINTA, "font": FUENTE, "fontSize": 11},
            "concat": {"spacing": 28},
            "facet": {"spacing": 24},
        }
    }


def enable() -> None:
    """Activa el estilo de casa y deja de truncar a 5.000 filas."""
    alt.theme.enable(THEME_NAME)
    alt.data_transformers.disable_max_rows()
