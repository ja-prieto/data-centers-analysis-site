"""Piezas compartidas: numeros en espanol, tarjetas y barras de ranking.

El formato es el problema de fondo. d3 solo sabe formatear a la inglesa
(«1,234.5») y el espanol usa los dos simbolos al reves, asi que `es_format`
los intercambia **a traves de un marcador**: una secuencia de reemplazos
directos convertiria los dos separadores en el mismo.

En el proyecto del que viene este modulo los tooltips no pasaban por ahi y
salian con separadores ingleses mientras los ejes salian bien. Aqui pasan los
dos: `tooltip_es` genera el campo calculado que hace falta.
"""

from __future__ import annotations

from collections.abc import Iterable

import altair as alt

from tema import BORDE, NEUTRO, REJILLA, ROJO, SUAVE, TEXTO, TINTA, VERDE

MILLON = 1_000_000
MIL_MILLONES = 1_000_000_000


def es_format(valor: str, spec: str = ",.0f", sufijo: str = "") -> str:
    """Expresion de Vega que formatea `valor` con separadores espanoles."""
    texto = f"format({valor}, '{spec}')"
    cambiado = f"replace(replace(replace({texto}, /\\./g, '@'), /,/g, '.'), /@/g, ',')"
    return f"{cambiado} + '{sufijo}'" if sufijo else cambiado


def es_numero(valor: float, decimales: int = 0) -> str:
    return f"{valor:,.{decimales}f}".translate(str.maketrans({",": ".", ".": ","}))


def es_euros(valor: float) -> str:
    """Euros a una escala legible: EUR, M EUR o mm EUR segun el tamano."""
    if abs(valor) >= MIL_MILLONES:
        return f"{es_numero(valor / MIL_MILLONES, 1)} mm EUR"
    if abs(valor) >= MILLON:
        return f"{es_numero(valor / MILLON, 1)} M EUR"
    return f"{es_numero(valor)} EUR"


def eje_dinero(titulo: str | None, spec: str = ",.0f", sufijo: str = " M EUR", **kwargs):
    return alt.Axis(title=titulo, labelExpr=es_format("datum.value", spec, sufijo), **kwargs)


def tooltip_es(campo: str, titulo: str) -> alt.Tooltip:
    """Tooltip numerico con separadores espanoles.

    Vega-Lite no admite `labelExpr` en un tooltip, asi que el formato se calcula
    como campo derivado y el valor viaja ya convertido en texto. El hueco sale
    como «sin dato», no como cero: es el convenio numero uno de la base.

    **Apunta a `<campo>_txt`, que tiene que haber creado `con_texto_es`.** El
    formato se declara alli y solo alli: si esta funcion aceptara tambien un
    `spec`, habria dos sitios donde decir el mismo formato y acabarian
    discrepando.
    """
    return alt.Tooltip(f"{campo}_txt:N", title=titulo)


def con_texto_es(
    grafico: alt.Chart, campos: dict[str, tuple[str, str]]
) -> alt.Chart:
    """Anade un `<campo>_txt` formateado a la espanola por cada campo numerico.

    `campos` es `{campo: (spec, sufijo)}`.
    """
    for campo, (spec, sufijo) in campos.items():
        grafico = grafico.transform_calculate(
            **{
                f"{campo}_txt": (
                    f"isValid(datum['{campo}']) ? "
                    f"{es_format(f"datum['{campo}']", spec, sufijo)} : 'sin dato'"
                )
            }
        )
    return grafico


# --------------------------------------------------------------------------- #
# Componentes HTML
# --------------------------------------------------------------------------- #


def tarjetas(items: Iterable[tuple[str, str, str]]) -> str:
    """Fila de cifras de cabecera, cada una `(etiqueta, valor, nota)`."""
    tarjetas_html = "".join(
        f"""<div style="flex:1 1 170px;padding:14px 16px;border:1px solid {REJILLA};
             border-left:3px solid {ROJO};border-radius:2px;background:#FFFFFF">
          <div style="font-size:11px;letter-spacing:.06em;text-transform:uppercase;
               color:{SUAVE}">{etiqueta}</div>
          <div style="font-size:24px;font-weight:600;color:{TINTA};margin-top:4px">{valor}</div>
          <div style="font-size:11px;color:{TEXTO};margin-top:2px">{nota}</div>
        </div>"""
        for etiqueta, valor, nota in items
    )
    return (
        f'<div style="display:flex;flex-wrap:wrap;gap:12px;margin:8px 0 4px">'
        f"{tarjetas_html}</div>"
    )


def aviso(texto: str) -> str:
    """Pie discreto para las advertencias que en estos datos no dejan de salir."""
    return (
        f'<div style="font-size:12px;color:{TEXTO};border-left:2px solid {BORDE};'
        f'padding:2px 0 2px 10px;margin:6px 0">{texto}</div>'
    )


def pasos(titulo: str, subtitulo: str, items: Iterable[tuple[str, str]]) -> str:
    """Cadena numerada de pasos, cada uno `(que, por que)`.

    Es lo primero que ve alguien que no conoce el proyecto, y lo unico que
    tiene que contestar es **de donde sale un dato**. Va en HTML y no en un
    grafico porque no hay ninguna magnitud que dibujar: es una secuencia, y
    dibujar una secuencia como barras seria fingir que se mide algo.
    """
    tarjetas_html = "".join(
        f"""<div style="flex:1 1 160px;min-width:150px;padding:12px 14px;
             border:1px solid {REJILLA};border-radius:2px;background:#FFFFFF">
          <div style="display:inline-flex;align-items:center;justify-content:center;
               width:20px;height:20px;border-radius:10px;background:{ROJO};
               color:#FFFFFF;font-size:11px;font-weight:600">{n}</div>
          <div style="font-size:13px;font-weight:600;color:{TINTA};margin-top:7px">{que}</div>
          <div style="font-size:11.5px;color:{TEXTO};margin-top:3px;
               line-height:1.45">{porque}</div>
        </div>"""
        for n, (que, porque) in enumerate(items, start=1)
    )
    return (
        f'<div style="border:1px solid {BORDE};border-left:3px solid {ROJO};'
        f'border-radius:2px;padding:12px 14px;background:#FFFFFF;margin:8px 0">'
        f'<div style="font-size:13px;font-weight:600;color:{TINTA}">{titulo}</div>'
        f'<div style="font-size:11.5px;color:{SUAVE};margin-bottom:10px">{subtitulo}</div>'
        f'<div style="display:flex;flex-wrap:wrap;gap:10px">{tarjetas_html}</div>'
        "</div>"
    )


def definiciones(titulo: str, subtitulo: str, items: Iterable[tuple[str, str]]) -> str:
    """Vocabulario controlado, cada entrada `(termino, que significa)`.

    Las columnas `fiabilidad` y `verificacion` son vocabulario cerrado y sus
    valores no se explican solos: `no_comprobable` **no es un aprobado**, y
    `OFICIAL-NP` es oficial y no es el expediente. Quien lee la tabla sin esto
    tiene que adivinar, y adivina mal.
    """
    filas_html = "".join(
        f"""<div style="display:flex;gap:10px;padding:7px 0;
             border-top:1px solid {BORDE}">
          <div style="flex:0 0 148px;font-size:12px;font-weight:600;color:{TINTA};
               font-family:ui-monospace,SFMono-Regular,Menlo,monospace">{termino}</div>
          <div style="flex:1;font-size:11.5px;color:{TEXTO};line-height:1.5">{texto}</div>
        </div>"""
        for termino, texto in items
    )
    return (
        f'<div style="border:1px solid {BORDE};border-left:3px solid {NEUTRO};'
        f'border-radius:2px;padding:12px 14px;background:#FFFFFF;margin:8px 0">'
        f'<div style="font-size:13px;font-weight:600;color:{TINTA}">{titulo}</div>'
        f'<div style="font-size:11.5px;color:{SUAVE}">{subtitulo}</div>'
        f"{filas_html}</div>"
    )


def estados(titulo: str, subtitulo: str, filas: Iterable[tuple[str, str, str, bool]]) -> str:
    """Lista de situaciones, cada una `(que, estado, por que, es_pendiente)`.

    Esto no es un grafico y no debe serlo. Antes era un diagrama de barras cuya
    longitud contaba documentos, y cuando las comunidades que faltaban pasaron
    de catorce a cinco la barra dejo de medir nada: cuatro de las cinco valian
    cero, y un grafico con cuatro barras invisibles no dice «no hay dato», dice
    que algo se ha roto. Lo que hay que enseñar aqui es **por que** cada una
    sigue fuera, y eso son palabras.

    `es_pendiente` distingue lo que queda por hacer de lo que ya es un
    resultado. Una comunidad buscada y vacia no es una tarea: poder decir «en
    Navarra no hay», con la busqueda registrada, vale tanto como nombrar un
    expediente en Aragon, y es lo que separa esto de una lista sacada de la
    prensa.
    """
    def _fila(que: str, estado: str, porque: str, pendiente: bool) -> str:
        color = ROJO if pendiente else VERDE
        marca = "pendiente" if pendiente else "resultado"
        return (
            f'<div style="display:flex;gap:10px;padding:9px 0;'
            f'border-top:1px solid {BORDE}">'
            f'<div style="flex:0 0 5px;background:{color};border-radius:3px"></div>'
            f'<div style="flex:1">'
            f'<div style="display:flex;justify-content:space-between;gap:8px">'
            f'<span style="font-weight:600;color:{TINTA};font-size:13px">{que}</span>'
            f'<span style="font-size:10px;letter-spacing:.05em;text-transform:uppercase;'
            f'color:{color};white-space:nowrap">{marca}</span></div>'
            f'<div style="font-size:12px;color:{TINTA};margin-top:1px">{estado}</div>'
            f'<div style="font-size:11.5px;color:{TEXTO};margin-top:3px;'
            f'line-height:1.45">{porque}</div>'
            "</div></div>"
        )

    cuerpo = "".join(_fila(*f) for f in filas)
    return (
        f'<div style="border:1px solid {BORDE};border-left:3px solid {ROJO};'
        f'border-radius:2px;padding:12px 14px;background:#FFFFFF">'
        f'<div style="font-size:13px;font-weight:600;color:{TINTA}">{titulo}</div>'
        f'<div style="font-size:11.5px;color:{SUAVE};margin-bottom:2px">{subtitulo}</div>'
        f"{cuerpo}</div>"
    )
